var networks = {"output.graphml": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "output.graphml",
    "name" : "output.graphml",
    "SUID" : 52,
    "__Annotations" : [ "" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "78",
        "shared_name" : "<s>",
        "name" : "<s>",
        "SUID" : 78,
        "label" : "<s>",
        "selected" : false
      },
      "position" : {
        "x" : -447.52996826171875,
        "y" : 39.45810890197754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "77",
        "shared_name" : "</s>",
        "name" : "</s>",
        "SUID" : 77,
        "label" : "</s>",
        "selected" : false
      },
      "position" : {
        "x" : 388.5887145996094,
        "y" : 39.45810890197754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "76",
        "shared_name" : "0-1",
        "name" : "0-1",
        "SUID" : 76,
        "label" : "二",
        "selected" : false
      },
      "position" : {
        "x" : -343.01513290405273,
        "y" : 39.45810890197754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "75",
        "shared_name" : "1-2",
        "name" : "1-2",
        "SUID" : 75,
        "label" : "十",
        "selected" : false
      },
      "position" : {
        "x" : -238.50029754638672,
        "y" : 39.45810890197754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "74",
        "shared_name" : "2-3",
        "name" : "2-3",
        "SUID" : 74,
        "label" : "四",
        "selected" : false
      },
      "position" : {
        "x" : -133.9854621887207,
        "y" : 39.45810890197754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "73",
        "shared_name" : "3-4",
        "name" : "3-4",
        "SUID" : 73,
        "label" : "口",
        "selected" : false
      },
      "position" : {
        "x" : -13.124645233154297,
        "y" : 44.22568893432617
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "72",
        "shared_name" : "4-5",
        "name" : "4-5",
        "SUID" : 72,
        "label" : "交",
        "selected" : false
      },
      "position" : {
        "x" : 75.04420852661133,
        "y" : 39.45810890197754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "71",
        "shared_name" : "5-6",
        "name" : "5-6",
        "SUID" : 71,
        "label" : "换",
        "selected" : false
      },
      "position" : {
        "x" : 179.55904388427734,
        "y" : 39.45810890197754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "70",
        "shared_name" : "6-7",
        "name" : "6-7",
        "SUID" : 70,
        "label" : "机",
        "selected" : false
      },
      "position" : {
        "x" : 284.07387924194336,
        "y" : 39.45810890197754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "69",
        "shared_name" : "5-7",
        "name" : "5-7",
        "SUID" : 69,
        "label" : "换机",
        "selected" : false
      },
      "position" : {
        "x" : 244.81466674804688,
        "y" : 122.4718246459961
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "68",
        "shared_name" : "4-6",
        "name" : "4-6",
        "SUID" : 68,
        "label" : "交换",
        "selected" : false
      },
      "position" : {
        "x" : 125.76658630371094,
        "y" : -28.522693634033203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "67",
        "shared_name" : "4-7",
        "name" : "4-7",
        "SUID" : 67,
        "label" : "交换机",
        "selected" : false
      },
      "position" : {
        "x" : 173.9000244140625,
        "y" : -100.83327102661133
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "66",
        "shared_name" : "3-5",
        "name" : "3-5",
        "SUID" : 66,
        "label" : "口交",
        "selected" : false
      },
      "position" : {
        "x" : 30.786407470703125,
        "y" : 122.4718246459961
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "65",
        "shared_name" : "2-4",
        "name" : "2-4",
        "SUID" : 65,
        "label" : "四口",
        "selected" : false
      },
      "position" : {
        "x" : -85.60016632080078,
        "y" : -28.522693634033203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "64",
        "shared_name" : "1-3",
        "name" : "1-3",
        "SUID" : 64,
        "label" : "十四",
        "selected" : false
      },
      "position" : {
        "x" : -179.2017822265625,
        "y" : 122.4718246459961
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "63",
        "shared_name" : "0-2",
        "name" : "0-2",
        "SUID" : 63,
        "label" : "二十",
        "selected" : false
      },
      "position" : {
        "x" : -289.11407470703125,
        "y" : -28.522693634033203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "62",
        "shared_name" : "0-3",
        "name" : "0-3",
        "SUID" : 62,
        "label" : "二十四",
        "selected" : false
      },
      "position" : {
        "x" : -237.66207885742188,
        "y" : -100.83327102661133
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "108",
        "source" : "78",
        "target" : "76",
        "shared_name" : "<s> (-) 0-1",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "<s> (-) 0-1",
        "interaction" : "-",
        "weight" : 0.0,
        "SUID" : 108,
        "round_weight" : 0.0,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "source" : "78",
        "target" : "63",
        "shared_name" : "<s> (-) 0-2",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "<s> (-) 0-2",
        "interaction" : "-",
        "weight" : 0.0,
        "SUID" : 107,
        "round_weight" : 0.0,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "106",
        "source" : "78",
        "target" : "62",
        "shared_name" : "<s> (-) 0-3",
        "shortest_path" : true,
        "shared_interaction" : "-",
        "name" : "<s> (-) 0-3",
        "interaction" : "-",
        "weight" : 0.0,
        "SUID" : 106,
        "round_weight" : 0.0,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "source" : "76",
        "target" : "75",
        "shared_name" : "0-1 (-) 1-2",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "0-1 (-) 1-2",
        "interaction" : "-",
        "weight" : 7.740522386693024,
        "SUID" : 105,
        "round_weight" : 7.74,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "104",
        "source" : "76",
        "target" : "64",
        "shared_name" : "0-1 (-) 1-3",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "0-1 (-) 1-3",
        "interaction" : "-",
        "weight" : 7.740522386693024,
        "SUID" : 104,
        "round_weight" : 7.74,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "source" : "75",
        "target" : "74",
        "shared_name" : "1-2 (-) 2-3",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "1-2 (-) 2-3",
        "interaction" : "-",
        "weight" : 8.933649304089666,
        "SUID" : 103,
        "round_weight" : 8.93,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "source" : "75",
        "target" : "65",
        "shared_name" : "1-2 (-) 2-4",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "1-2 (-) 2-4",
        "interaction" : "-",
        "weight" : 8.933649304089666,
        "SUID" : 102,
        "round_weight" : 8.93,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "101",
        "source" : "74",
        "target" : "73",
        "shared_name" : "2-3 (-) 3-4",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "2-3 (-) 3-4",
        "interaction" : "-",
        "weight" : 8.054633161120252,
        "SUID" : 101,
        "round_weight" : 8.05,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "source" : "74",
        "target" : "66",
        "shared_name" : "2-3 (-) 3-5",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "2-3 (-) 3-5",
        "interaction" : "-",
        "weight" : 8.054633161120252,
        "SUID" : 100,
        "round_weight" : 8.05,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "source" : "73",
        "target" : "72",
        "shared_name" : "3-4 (-) 4-5",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "3-4 (-) 4-5",
        "interaction" : "-",
        "weight" : 7.969903064209569,
        "SUID" : 99,
        "round_weight" : 7.97,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98",
        "source" : "73",
        "target" : "68",
        "shared_name" : "3-4 (-) 4-6",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "3-4 (-) 4-6",
        "interaction" : "-",
        "weight" : 7.969903064209569,
        "SUID" : 98,
        "round_weight" : 7.97,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "97",
        "source" : "73",
        "target" : "67",
        "shared_name" : "3-4 (-) 4-7",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "3-4 (-) 4-7",
        "interaction" : "-",
        "weight" : 7.969903064209569,
        "SUID" : 97,
        "round_weight" : 7.97,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "96",
        "source" : "72",
        "target" : "71",
        "shared_name" : "4-5 (-) 5-6",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "4-5 (-) 5-6",
        "interaction" : "-",
        "weight" : 9.207714358149799,
        "SUID" : 96,
        "round_weight" : 9.21,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95",
        "source" : "72",
        "target" : "69",
        "shared_name" : "4-5 (-) 5-7",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "4-5 (-) 5-7",
        "interaction" : "-",
        "weight" : 9.207714358149799,
        "SUID" : 95,
        "round_weight" : 9.21,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "source" : "71",
        "target" : "70",
        "shared_name" : "5-6 (-) 6-7",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "5-6 (-) 6-7",
        "interaction" : "-",
        "weight" : 9.13461443266505,
        "SUID" : 94,
        "round_weight" : 9.13,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "93",
        "source" : "70",
        "target" : "77",
        "shared_name" : "6-7 (-) </s>",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "6-7 (-) </s>",
        "interaction" : "-",
        "weight" : 9.066928394454745,
        "SUID" : 93,
        "round_weight" : 9.07,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "source" : "69",
        "target" : "77",
        "shared_name" : "5-7 (-) </s>",
        "shortest_path" : true,
        "shared_interaction" : "-",
        "name" : "5-7 (-) </s>",
        "interaction" : "-",
        "weight" : 16.119793608611992,
        "SUID" : 92,
        "round_weight" : 16.12,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "source" : "68",
        "target" : "70",
        "shared_name" : "4-6 (-) 6-7",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "4-6 (-) 6-7",
        "interaction" : "-",
        "weight" : 9.72871436707402,
        "SUID" : 91,
        "round_weight" : 9.73,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "90",
        "source" : "67",
        "target" : "77",
        "shared_name" : "4-7 (-) </s>",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "4-7 (-) </s>",
        "interaction" : "-",
        "weight" : 13.051740673478374,
        "SUID" : 90,
        "round_weight" : 13.05,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "source" : "66",
        "target" : "71",
        "shared_name" : "3-5 (-) 5-6",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "3-5 (-) 5-6",
        "interaction" : "-",
        "weight" : 16.812940789171936,
        "SUID" : 89,
        "round_weight" : 16.81,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "88",
        "source" : "66",
        "target" : "69",
        "shared_name" : "3-5 (-) 5-7",
        "shortest_path" : true,
        "shared_interaction" : "-",
        "name" : "3-5 (-) 5-7",
        "interaction" : "-",
        "weight" : 16.812940789171936,
        "SUID" : 88,
        "round_weight" : 16.81,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "87",
        "source" : "65",
        "target" : "72",
        "shared_name" : "2-4 (-) 4-5",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "2-4 (-) 4-5",
        "interaction" : "-",
        "weight" : 13.594064964303735,
        "SUID" : 87,
        "round_weight" : 13.59,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "86",
        "source" : "65",
        "target" : "68",
        "shared_name" : "2-4 (-) 4-6",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "2-4 (-) 4-6",
        "interaction" : "-",
        "weight" : 13.594064964303735,
        "SUID" : 86,
        "round_weight" : 13.59,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "85",
        "source" : "65",
        "target" : "67",
        "shared_name" : "2-4 (-) 4-7",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "2-4 (-) 4-7",
        "interaction" : "-",
        "weight" : 13.594064964303735,
        "SUID" : 85,
        "round_weight" : 13.59,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84",
        "source" : "64",
        "target" : "73",
        "shared_name" : "1-3 (-) 3-4",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "1-3 (-) 3-4",
        "interaction" : "-",
        "weight" : 10.512766802420098,
        "SUID" : 84,
        "round_weight" : 10.51,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83",
        "source" : "64",
        "target" : "66",
        "shared_name" : "1-3 (-) 3-5",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "1-3 (-) 3-5",
        "interaction" : "-",
        "weight" : 10.512766802420098,
        "SUID" : 83,
        "round_weight" : 10.51,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82",
        "source" : "63",
        "target" : "74",
        "shared_name" : "0-2 (-) 2-3",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "0-2 (-) 2-3",
        "interaction" : "-",
        "weight" : 10.661627541122058,
        "SUID" : 82,
        "round_weight" : 10.66,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81",
        "source" : "63",
        "target" : "65",
        "shared_name" : "0-2 (-) 2-4",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "0-2 (-) 2-4",
        "interaction" : "-",
        "weight" : 10.661627541122058,
        "SUID" : 81,
        "round_weight" : 10.66,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80",
        "source" : "62",
        "target" : "73",
        "shared_name" : "0-3 (-) 3-4",
        "shortest_path" : false,
        "shared_interaction" : "-",
        "name" : "0-3 (-) 3-4",
        "interaction" : "-",
        "weight" : 12.165349887299893,
        "SUID" : 80,
        "round_weight" : 12.17,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "79",
        "source" : "62",
        "target" : "66",
        "shared_name" : "0-3 (-) 3-5",
        "shortest_path" : true,
        "shared_interaction" : "-",
        "name" : "0-3 (-) 3-5",
        "interaction" : "-",
        "weight" : 12.165349887299893,
        "SUID" : 79,
        "round_weight" : 12.17,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}